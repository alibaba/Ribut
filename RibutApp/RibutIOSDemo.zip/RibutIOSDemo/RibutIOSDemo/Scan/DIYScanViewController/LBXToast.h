//
//  TKTool.h
//  HandKooPDSDKDemo
//
//  Created by lbxia on 2018/5/7.
//  Copyright © 2018年 HDTK. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface LBXToast : NSObject

///toast
+ (void)showToastWithMessage:(NSString*)message;



@end
